***********************
Managing Standard Types
***********************


A user can manipulate and extend these CSV-files if required as long as one sticks to the given
data structure. If you want to add own further components to the standard types library,
please do not hesitate to contribute. If in your opinion something is missing in the standard type
structure of one component, please let us know and open a corresponding issue.

In order to add new standard types one needs to do following steps:

- still in process

********************
Basic Standard Types
********************

Every pandapipes network comes with a default set of standard types. The required information
of each standard type is stored separately as CSV file under std_types.<component_name>.

The function calling the standard types and storing them to a pandapipes net is
:code:`add_basic_std_types(net)`.

.. autofunction:: pandapipes.add_basic_std_types

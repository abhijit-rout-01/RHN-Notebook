
.. _fluids_auxiliary:

*************************
Auxiliary Fluid Functions
*************************

There are some functions for auxiliary purposes which are listed in the following:

- Get the fluid that is used in an existing network:

.. autofunction:: pandapipes.properties.fluids.get_fluid

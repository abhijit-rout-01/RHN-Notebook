.. _properties:

################
Fluid Properties
################

.. toctree::
    :maxdepth: 1

    fluid_properties/fluids
    fluid_properties/create_fluids
    fluid_properties/fluids_auxiliary


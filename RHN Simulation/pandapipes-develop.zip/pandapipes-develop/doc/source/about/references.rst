﻿.. _references:

**********
References
**********

.. bibliography:: ../references.bib
  :all:


﻿.. _license:

*******
License
*******

.. highlight:: none


pandapipes is published under the following 3-clause BSD license:

    .. literalinclude:: ../../../LICENSE


﻿.. _symbols:

*******
Symbols
*******

Some sections of this documentation contain equations implemented by pandapipes. The meaning of the symbols used in
these equations is explained here.

.. tabularcolumns:: |l|l|
.. csv-table:: 
   :file: symbols.csv
   :delim: ;
   :widths: 15, 30


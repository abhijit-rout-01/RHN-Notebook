﻿.. _authors:

*******
Authors
*******


.. include:: ../../../AUTHORS

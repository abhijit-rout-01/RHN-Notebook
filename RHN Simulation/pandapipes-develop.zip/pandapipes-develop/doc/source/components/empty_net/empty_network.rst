*************
Empty Network
*************

As the first step to create your own pandapipes network, you have to call the function
:code:`create_empty_network()`. This creates the pandapipesNet data structure which can then be
filled with additional elements described in the following sections.


Create Function
===============
.. _create_empty_net:

.. autofunction:: pandapipes.create_empty_network

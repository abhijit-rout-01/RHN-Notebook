.. _std_types:

##############
Standard Types
##############

.. toctree::
    :maxdepth: 1

    standard_types/std_types_in_pandapipes
    standard_types/basic_standard_types
    standard_types/managing_standard_types


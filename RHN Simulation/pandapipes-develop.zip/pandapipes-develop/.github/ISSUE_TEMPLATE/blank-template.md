---
name: Blank template
about: Template for issues that are no bug report or feature request
title: ''
labels: ''
assignees: ''

---

If there is already a similar issue, please consider upvoting it.
